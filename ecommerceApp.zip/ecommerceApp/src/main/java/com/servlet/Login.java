package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	boolean validateUser(String name) 
	{
    	if(name.equals(" ") || name.length()<6) {
    		return false;
    	}
    	else
    		return true;
    }
    boolean validatePassword(String password) 
    {
    	if("abc1234".equals(password)) {
    		return true;
    	}
    	else 
    		return false;
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			String name=request.getParameter("uname");
			String password=request.getParameter("password");
			Boolean validate=validateUser(name);
			if(validate) {
				if(validatePassword(password)) {
					out.println("<br>You have successfully logged in");
					out.println("<br><br><br>Welcome!! " + name);
					out.println("<br><br><br>Welcome to Aura Galleria!! ");
					HttpSession session=request.getSession();
					session.setAttribute("name",name);
					
					out.println("<html>");
					out.println("<head>");
					out.println("<title>Welcome</title>");
					out.println("</head>");
					out.println("<body>");
					out.println("<form action='payment' method='post'>");
					out.println("<table width=400  >");
					out.println("<tr><td>Item Number</td><td>Item Name</td><td>Select to buy</td>");
					out.println("<tr><td>1</td><td>Dress Materials</td><td><input type='checkbox' name='item1' value='dress'> </td>");		
					
					
			}
				else
				{
					response.sendError(407,"Need Authentication");
					out.print("<br>Sorry! Password incorrect!");
					//request.getRequestDispatcher("login.html").include(request, response);
				}
			}
			else
			{
				
				response.sendError(407,"Need Authentication");
				out.print("<br>Sorry! Username not valid!");
				//request.getRequestDispatcher("login.html").include(request, response);
			}
			
			out.close();
		}catch(Exception e) {
			throw new ServletException();
		}
	}

	

}
